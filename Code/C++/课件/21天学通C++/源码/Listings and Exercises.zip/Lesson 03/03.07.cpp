// LISTING 3.7 - Printing Characters Based on Numbers, Take 2
#include <iostream>

int main()
{
    for (unsigned char i = 32; i<128; i++)
        std::cout << i;

    return 0;
}