// LISTING 20.1 - Instantiating STL Set and Multiset of Integers
#include <set>

int main ()
{
    using namespace std;

    set <int> setIntegers;
    multiset <int> msetIntegers;

    return 0;
}