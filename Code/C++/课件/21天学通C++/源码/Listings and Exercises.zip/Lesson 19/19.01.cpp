// LISTING 19.1 Instantiating an STL List of Integers
#include <list>

int main ()
{
    using namespace std;

    list <int> listIntegers;

    return 0;
}

// This program produces no output