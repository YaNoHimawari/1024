// Listing 17.10 - Using put()
  
#include <iostream>
  
int main()
{
   std::cout.put('H').put('e').put('l').put('l').put('o').put('\n');
   return 0;
}
