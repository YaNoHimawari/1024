class myDate
{
public:
    // stuff here...
private:
    unsigned int Month : 4;
    unsigned int Day : 8;
    unsigned int Year : 12;
}