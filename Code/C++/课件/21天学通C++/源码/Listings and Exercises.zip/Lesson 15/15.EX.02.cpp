template <typename T>
T Add (const T& x, const T& y)
{
    return (x + y);
}