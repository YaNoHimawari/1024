int main()
{
    int * pVar;
    *pVar = 9;
    return 0;
}