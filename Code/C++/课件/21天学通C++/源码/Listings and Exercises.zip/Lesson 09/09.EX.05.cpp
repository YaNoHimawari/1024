int main()
{
    int VarOne;
    int * pVar = &varOne;
    *pVar = 9;
    return 0;
}