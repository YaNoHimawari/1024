#include <iostream>
using namespace std;
int main()
{
    cout << "I love C++\n";
    return 0;
}