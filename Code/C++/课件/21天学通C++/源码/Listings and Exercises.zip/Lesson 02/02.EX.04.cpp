#include <iostream>
main()
{
    std::cout << "Is there a bug here?";
}