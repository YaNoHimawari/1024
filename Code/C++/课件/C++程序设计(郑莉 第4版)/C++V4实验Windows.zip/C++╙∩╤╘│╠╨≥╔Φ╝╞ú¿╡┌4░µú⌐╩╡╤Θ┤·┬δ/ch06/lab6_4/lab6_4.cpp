#include <iostream>
#include <string>
using namespace std;

int main()
{
	string s1 = "abc", s2 = "def";
	cout << s1 + s2 << endl;
	return 0;
}