#include "my_x_y_z.h"
int main() 
{
	X x;
	Z z;
	z.f(&x);
	return 0;
}
