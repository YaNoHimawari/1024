#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	int x = 0, y = 0;
	cout << "input x and y:" << endl;
	cin >> x >> y;
	cout << "x^y = " << pow(1.0*x, y) << endl;
	return 0;
}
