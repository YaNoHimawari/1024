#include <iostream>
using namespace std ;
int main()
{
     cout<<"Hello!\n";
     cout<<"Welcome to c++!\n";
     return 0;
}
